from core.service import ImageReceiver
from core.config import car_tb, tvs_alwayson
from car_match.yolo2py.darknet import Darknet19
import car_match.yolo2py.utils.yolo as yolo_utils
import car_match.yolo2py.utils.network as net_utils
import car_match.yolo2py.cfgs.config as cfg
from PIL import Image
import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models
from torchvision import transforms
from torch.autograd import Variable
from core.config import carinfo_tb, similaritymodelpath, yolomodelpath, log_db, geo_loc
import os
import uuid
import datetime
import time
import base64
from utils.upload_img import upload
import threading

class yoloNet():
    def __init__(self, modelpath):
        self.thresh = 0.5
        self.label = ('car', 'truck', 'trailer', 'bus')
        self.net = Darknet19()
        self.net.load_state_dict(torch.load(yolomodelpath))
        #net_utils.load_net(modelpath, self.net)
        self.net.cuda()
        self.net.eval()
        print('Yolo init Success')

    def preprocess(self, content, method = 'nparray'):
        image = 0
        if method == 'path':
            image = cv2.imread(content)
        elif method == 'nparray':
            image = content
        else:
            print('\n\nError in preprocess\n\n')
        #yolo_utils.preprocess_test((image, none, cfg.multi_scale_inp_size), 0)将图像转换到RGB空间,resize到(320, 320),值归一化到(0,1)返回的0号元素为处理后图像,4号元素为原图拷贝
        im_data = np.expand_dims(yolo_utils.preprocess_test((image, None, cfg.multi_scale_inp_size), 0)[0], 0)
        #im_data被转换为(1,3,320,320)归一化np矩阵
        return image, im_data

    #输入path
    def getCarinfofromPic(self, content, method = 'nparray'):
        image, im_data= self.preprocess(content, method = method)
        im_data = net_utils.np_to_variable(im_data, is_cuda=True, volatile=True).permute(0, 3, 1, 2)
        bbox_pred, iou_pred, prob_pred = self.net(im_data)

        bbox_pred = bbox_pred.data.cpu().numpy()
        iou_pred = iou_pred.data.cpu().numpy()
        prob_pred = prob_pred.data.cpu().numpy()

        bboxes, scores, cls_inds = yolo_utils.postprocess(bbox_pred, iou_pred, prob_pred, image.shape, cfg, self.thresh, size_index=0)

        roi = []
        for i in range(len(bboxes)):
            roiimage = image[bboxes[i][1]:bboxes[i][3], bboxes[i][0]:bboxes[i][2]]
            roi.append(roiimage)

        return bboxes, scores, cls_inds, image, roi

    #不返回car
    def getCarROIpil(self, content, method = 'nparray'):
        bboxes, scores, cls_inds, ori_image, roi = self.getCarinfofromPic(content , method)
        newbboxes , newscores, newcls_inds, newori_image, newroi = [], [], [], [], []
        carImage = []

        cars_loc = []
        for i in range(len(cls_inds)):
            if cls_inds[i]!=0:
                pilroi = Image.fromarray(cv2.cvtColor(roi[i],cv2.COLOR_BGR2RGB))
                carImage.append(pilroi)
                newbboxes.append(bboxes[i])
                newscores.append(scores[i])
                newcls_inds.append(cls_inds[i])
            cars_loc.append(bboxes[i])
        return carImage, newbboxes, newscores, newcls_inds, cars_loc

class BaseNetwork(nn.Module):

    def __init__(self, modelname):
        super(BaseNetwork, self).__init__()
        self.modelname = modelname
        if modelname == 'Vgg16':
            self.CNN = models.vgg16(pretrained=True).features
            self.FC1 = nn.Linear(7*7*512, 2048)
            self.FC2 = nn.Linear(2048, 128)
        else:

            raise ('Please select model')

    def forward(self, x):
        if self.modelname == 'Vgg16':
            output = self.CNN(x)
            output = output.view(output.size()[0], -1)
            output = self.FC1(output)
            output = F.relu(output)
            output = self.FC2(output)
        else:
            raise ('Please select model')
        return output



class similarity():
    def __init__(self, modelpath):
        self.model = BaseNetwork('Vgg16')
        self.model.load_state_dict(torch.load(modelpath))
        self.model.cuda()
        #self.tranform = transforms.Compose([transforms.RandomResizedCrop(224, scale=(0.8, 1.0)), transforms.ColorJitter(), transforms.ToTensor(),transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

        self.tranform = transforms.Compose([transforms.Resize((224, 224)), transforms.ToTensor(),transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
    def getEmbeddingformPILlist(self, pillist):
        featurelist = []

        for pilimage in pillist:
            tensorimage =  Variable(self.tranform(pilimage)).view(1, 3, 224, 224).cuda()
            feature = self.model(tensorimage)
            featurelist.append(feature)
        return featurelist

class SaveCarInfo(ImageReceiver):
    def __init__(self, ID, savepicpath, cameraID):
        self.info = None
        self.cartb = log_db[cameraID + '_car']
        if not hasattr(SaveCarInfo, "yolo"):
            SaveCarInfo.yolo = yoloNet(yolomodelpath)
        if not hasattr(SaveCarInfo, "simi"):
            SaveCarInfo.simi = similarity(similaritymodelpath)

        self.savepicpath = savepicpath
        self.cameraid = cameraID
        self.id = ID
        self.lastt = 0
        self.carcount = 0
        self.ifsavefeature = True if (self.cameraid in tvs_alwayson) else False

    def feed(self, info):
        frame = info['img']

        carImagelist, bboxes, scores, cls_inds, cars_loc = SaveCarInfo.yolo.getCarROIpil(frame, 'nparray')
        
        ifsaveimage = False
        picpath = self.savepicpath
        imageid = str(uuid.uuid1())
        curt = info['time']
        imagepath = picpath + '/' + self.cameraid  + '_'  + str(curt) +'.jpg'


        #保存cars_loc
        if len(cars_loc)>0:
            ifsaveimage = True
            print(imagepath)
            self.cartb.insert_one({'time':curt, 'dt':curt-self.lastt,'content':'upload car', 'imagepath':imagepath})
        
        for car_loc in cars_loc:
            cameraid = self.cameraid
            location = car_loc
            location = [int(l) for l in location]
            info = {'cameraid':cameraid,
                    'imagepath':imagepath,
                    'time':curt,
                    'location':location,
                    'info':''
                    }
            car_tb.insert(info)
                        

        
        #保存feature信息
        if self.ifsavefeature:
            featurelist = SaveCarInfo.simi.getEmbeddingformPILlist(carImagelist)
            carinfolist = []
            for i, feature in enumerate(featurelist):

                carid = str(uuid.uuid1())
                # feature 转化为一个128维[float, float],供数据库存储
                feature = list(feature.cpu().data.numpy().flatten())
                feature = [int(f*1000) for f in feature]
                location = bboxes[i]
                location = [int(l) for l in location]
                cameraid = self.cameraid
                area = (location[2]-location[0])*(location[3]-location[1])

                y = (location[1] + location[3])/2
                y = int((1080-y)/1080 * 100 + 20)
                pos_1, pos_2 = geo_loc[cameraid]
                pos_2 += y
                if pos_2>1000:
                    pos_2 -= 1000
                    pos_1 += 1
                pos = 'K' + str(pos_1) + '+' + str(pos_2)
            
                if area>150*150:
                    carinfo = {'carid' : carid,
                            'imageid' : imageid,
                            'time' : curt,
                            'feature': feature,
                            'cameraid': cameraid,
                            'location' : location,
                            'position' : pos,
                            'info' : '',
                            'imagepath' : imagepath
                            }
                    carinfolist.append(carinfo)

        if ifsaveimage:
            print('upload image')
            
            for carinfo in carinfolist:
                carinfo_tb.insert_one(carinfo)
            lowppi_frame = cv2.resize(frame, (800, 450))
            ret, buffer = cv2.imencode('.jpg', lowppi_frame)
            if ret:
                b64img = base64.b64encode(buffer)
                #upload(imagepath, b64img)
                up_thread = threading.Thread(target=upload, args=(imagepath, b64img,))
                up_thread.start()
                self.cartb.insert_one({'time':curt, 'dt':curt-self.lastt,'content':'upload car', 'imagepath':imagepath})
                self.carcount += 1
                if self.carcount%60 == 0:
                    print(cameraid+ '  car\t' + str(self.carcount))
                self.lastt = curt
