from core.service import ImageReceiver
import time
import datetime
import uuid
from core.config import rec_img_tb, log_db
import cv2
import os
from core.config import _recimgsavepath
from PIL import Image
import base64
from urllib import request, parse
import numpy as np
from utils.upload_img import upload
import threading

class SaveRecentImg(ImageReceiver):
    def __init__(self, ID, cameraid):
        self.id = ID
        self.info = None
        self.savepath = _recimgsavepath +cameraid +'/'
        self.cameraid = cameraid
        self.tb = log_db[cameraid + '_rec']

        self.lastt = 0
        self.reccount = 0        


    def feed(self, info):
        frame = info['img']
        imageid = str(uuid.uuid1())
        
        t = info['time']
        cameraid = self.cameraid
        imagepath = self.savepath + self.cameraid + '_' + str(t) + '.jpg'
        
        lowppi_frame = cv2.resize(frame, (800, 450))
        ret, buffer = cv2.imencode('.jpg', lowppi_frame)
        if ret:
            b64img = base64.b64encode(buffer)
            self.tb.insert_one({'time':t, 'lastt':self.lastt,'dt':t-self.lastt, 'content':'saveimg','imagepath':imagepath})
            
            up_thread = threading.Thread(target=upload, args=(imagepath, b64img))
            up_thread.start()
            #upload(imagepath, b64img)
            recent_img_info = {
                'imageid':imageid,
                'time':t,
                'cameraid':cameraid,
                'imagepath':imagepath,
                'info':''
                }
            rec_img_tb.insert_one(recent_img_info)
            self.reccount += 1
            if self.reccount%(60) == 0:
                print(self.cameraid + '  recimg\t' + str(self.reccount))
            self.lastt = t
