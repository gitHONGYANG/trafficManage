export PATH=/home/highway/anaconda3/bin:$PATH

nohup python /home/highway/Highway/bottomlayer/rtsp/rtsp_basereader.py TV4 > /home/highway/Highway/bottomlayer/rtsp/log/log_readerTV4.txt 2>&1 &
nohup python /home/highway/Highway/bottomlayer/rtsp/rtsp_basereader.py TV5 > /home/highway/Highway/bottomlayer/rtsp/log/log_readerTV5.txt 2>&1 &
nohup python /home/highway/Highway/bottomlayer/rtsp/rtsp_basereader.py TV6 > /home/highway/Highway/bottomlayer/rtsp/log/log_readerTV6.txt 2>&1 &
nohup python /home/highway/Highway/bottomlayer/rtsp/rtsp_basereader.py TV7 > /home/highway/Highway/bottomlayer/rtsp/log/log_readerTV7.txt 2>&1 &
nohup python /home/highway/Highway/bottomlayer/rtsp/rtsp_basereader.py TV8 > /home/highway/Highway/bottomlayer/rtsp/log/log_readerTV8.txt 2>&1 &
nohup python /home/highway/Highway/bottomlayer/rtsp/rtsp_basereader.py TV9 > /home/highway/Highway/bottomlayer/rtsp/log/log_readerTV9.txt 2>&1 &
nohup python /home/highway/Highway/bottomlayer/rtsp/rtsp_basereader.py TV10 > /home/highway/Highway/bottomlayer/rtsp/log/log_readerTV10.txt 2>&1 &
nohup python /home/highway/Highway/bottomlayer/rtsp/rtsp_basereader.py TV11 > /home/highway/Highway/bottomlayer/rtsp/log/log_readerTV11.txt 2>&1 &
nohup python /home/highway/Highway/bottomlayer/rtsp/rtsp_basereader.py TV12 > /home/highway/Highway/bottomlayer/rtsp/log/log_readerTV12.txt 2>&1 &
nohup python /home/highway/Highway/bottomlayer/rtsp/rtsp_basereader.py TV13 > /home/highway/Highway/bottomlayer/rtsp/log/log_readerTV13.txt 2>&1 &

nohup python /home/highway/Highway/bottomlayer/rtsp/rtsp_basereader.py TV52 > /home/highway/Highway/bottomlayer/rtsp/log/log_readerTV52.txt 2>&1 &
nohup python /home/highway/Highway/bottomlayer/rtsp/rtsp_basereader.py TV53 > /home/highway/Highway/bottomlayer/rtsp/log/log_readerTV53.txt 2>&1 &
nohup python /home/highway/Highway/bottomlayer/rtsp/rtsp_basereader.py TV54 > /home/highway/Highway/bottomlayer/rtsp/log/log_readerTV54.txt 2>&1 &
nohup python /home/highway/Highway/bottomlayer/rtsp/rtsp_basereader.py TV55 > /home/highway/Highway/bottomlayer/rtsp/log/log_readerTV55.txt 2>&1 &
nohup python /home/highway/Highway/bottomlayer/rtsp/rtsp_basereader.py TV56 > /home/highway/Highway/bottomlayer/rtsp/log/log_readerTV56.txt 2>&1 &
