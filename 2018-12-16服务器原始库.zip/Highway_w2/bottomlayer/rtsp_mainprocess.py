from core.service import Manager, LogReceiver
from core.config import carinfo_tb, _carmatchsavepath, obj_tb, vis_tb, rec_img_tb, car_tb, tvconfig_tb
from provider.rtspprovider import RtspProvider
from receiver.carmatchreceiver import SaveCarInfo
from receiver.visreceiver import SaveVis
from receiver.objreceiver_original import ObjDetecteReceiver
from receiver.recimgreceiver import SaveRecentImg
import time
import os
import sys

tvs = ['TV4', 'TV5', 'TV6', 'TV7', 'TV8', 'TV9', 'TV10', 'TV11', 'TV12', 'TV13']

i = int(sys.argv[1])
if i == 0:
    tvs = tvs[0:3] + ['TV52']
elif i == 1:
    tvs = tvs[3:6] + ['TV53']
elif i == 2:
    tvs = tvs[6:9] + ['TV54'] 
elif i == 3:
    tvs = tvs[9:10] + ['TV55', 'TV56']

print('tvlist\t', str(tvs))

def clean_tbs():
    carinfo_tb.remove({})
    obj_tb.remove({})
    vis_tb.remove({})
    rec_img_tb.remove({})

manager = Manager()
def build_provider():
    providers = [RtspProvider(i, tv) for i, tv in enumerate(tvs)]
    for i in providers:
        manager.add_provider(i)

def carmatch_receiver():
    for i, tv in enumerate(tvs):
        picpath = _carmatchsavepath + tv
        TVID = tv
        function = SaveCarInfo(i, picpath, TVID)
        function.span(0.6)
        manager.add_receiver(function)

def obj_receiver():
    for i, tv in enumerate(tvs):
        function = ObjDetecteReceiver(i, tv)
        function.span(1)
        manager.add_receiver(function)

def vis_receiver():
    for i, tv in enumerate(tvs):
        function = SaveVis(i, tv)
        function.span(30)
        manager.add_receiver(function)

def rec_receiver():
    for i, tv in enumerate(tvs):
        function = SaveRecentImg(i, tv)
        function.span(10)
        manager.add_receiver(function)

if __name__ == '__main__':
    rec_receiver()
    vis_receiver()
    carmatch_receiver()
    obj_receiver()
    build_provider()
    manager.hold(True)
    time.sleep(24*60*3600)
