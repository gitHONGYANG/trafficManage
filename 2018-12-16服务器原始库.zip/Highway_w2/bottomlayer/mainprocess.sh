cd /home/highway/Highway/bottomlayer/rtsp/

./rtsp_mainprocess1.sh
./rtsp_mainprocess2.sh
./rtsp_mainprocess3.sh
./rtsp_mainprocess4.sh
