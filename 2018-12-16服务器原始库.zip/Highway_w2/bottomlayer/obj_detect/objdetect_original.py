import numpy as np
import copy
from core.config import _objimgsavepath, _objrawimgsavepath, obj_tb, accident_tb, geo_loc, objmodelpath
import uuid
import base64
from urllib import request, parse
from utils.obj_varify import ObjValidation
from utils.obj_utils_original import calc_variance, contour_density_filter, morph, extra_mask_roi
from utils.region_judge import region_judge
import time
import os
from collections import deque
import cv2
from utils.upload_img import upload
from utils.upload_video import upload_video
import datetime
from core.config import obj_tb, car_tb
import threading

fourcc = cv2.VideoWriter_fourcc(*'XVID')

class HighWayObjDetect:
    def __init__(self,camera_id, modelpath):
        if not hasattr(HighWayObjDetect, 'objval'):
            #HighWayObjDetect.objval = ObjValidation(modelpath)
            HighWayObjDetect.objval = ObjValidation(objmodelpath)
            print('model init')

        self.camera_id = camera_id
        self.full_mask = cv2.imread('/home/highway/Highway/bottomlayer/road_mask/'+self.camera_id.lower()+'mask.png')
        self.mask, self.mask_w, self.mask_h, self.roi_w, self.roi_h = extra_mask_roi(self.full_mask)

        self.init_frames = 200
        self.build_bg_count = 0
        self.build_bg_done = False

        self.bg_queue = deque(maxlen=15)

        self.fg_queue = deque(maxlen=20)

        self.fgbg = cv2.createBackgroundSubtractorMOG2(history=self.init_frames, varThreshold=25, detectShadows=True)

        self.objoccurtimes = 0
        self.objoccurtimes_maxnum = 15
        self.objoccurtimes_judgenum = 10
        self.bgfg_outputboxes = []
        self.fod_box = []

        self.failcount = 0
        self.rightcount = 0
        
        #for judge weather insert an obj_info
        #fortest
        #self.db_search_startt = time.mktime(datetime.date(2018, 10, 14).timetuple())
        self.db_search_startt = time.mktime(datetime.date.today().timetuple())
        #self.car_save_startt = time.mktime(datetime.date(2018, 7, 14).timetuple())

        self.ifsave_video = False
        self.save_video_initt = 0
        self.is_stop_car = False

        self.car_accident_time = 0
        self.stop_cars = []

        self.save_video_type = 'obj'
        self.lastt = 0

    def build_bg(self, image):
        self.image = image#原图

        self.image_road = image[self.roi_h:self.mask_h, self.roi_w:self.mask_w, :]

        if not self.build_bg_done: #背景初始化
            self.fgbg.apply(self.image_road)

        else:#背景更新
            roiimage = self.image_road.copy()
            if len(self.bgfg_outputboxes) > 0:
                for item in self.fod_box:
                    x0 = int(item[0] - int(item[2] / 2))
                    y0 = int(item[1] - int(item[3] / 2))
                    x1 = x0 + item[2]
                    y1 = y0 + item[3]
                    roiimage[y0:y1, x0:x1] = self.bg[y0:y1, x0:x1]
            self.fgbg.apply(roiimage)

        if self.build_bg_count == self.init_frames:
            self.build_bg_done = True
            self.bg = self.fgbg.getBackgroundImage()
            self.bg_pre = self.bg
            self.bg_queue.append(self.bg)
        else:
            self.build_bg_count += 1
            print('build bg {}/{}'.format(self.build_bg_count, self.init_frames))
            self.bg = self.fgbg.getBackgroundImage()
            self.bg_queue.append(self.bg)
    def post_fix_bg(self):
        if len(self.bgfg_outputboxes):
            fm = copy.deepcopy(self.image_road)
            for item in self.fod_box:
                x0 = int(item[0] - int(item[2]/2))
                y0 = int(item[1] - int(item[3]/2))
                x1 = x0 + item[2]
                y1 = y0 + item[3]
                self.bg_queue[-15][y0:y1, x0:x1] = self.bg_pre[y0:y1, x0:x1]
        self.bg_pre = self.bg_queue[-15]

    def extract_fg(self):#提取前景
        if self.build_bg_done:
            self.fg = cv2.absdiff(self.image_road, self.bg)
            self.fg = self.fg *(self.mask>0)
            gray = cv2.cvtColor(self.fg, cv2.COLOR_BGR2GRAY)
            ret, fg_raw = cv2.threshold(gray, 30, 255, cv2.THRESH_BINARY)
            self.fg_bin = morph(fg_raw,3,8)
            self.post_fix_bg()

    def find_coutours_update_boxes(self, fgimage):
        (_, cnts, _) = cv2.findContours(fgimage, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_KCOS)

        if self.objoccurtimes == 0:
            self.boxes_pre = []
        org_h = self.mask_h - self.roi_h
        boxes, cnt_poten = contour_density_filter(cnts, 150, 160000, org_h)

        '''
        for box in boxes:
            x0 = int(box[0]-box[2]/2)
            y0 = int(box[1]-box[3]/2)
            x1 = int(box[0]+box[2]/2)
            y1 = int(box[1]+box[3]/2)
            cv2.rectangle(self.vis, (x0,y0), (x1,y1), (255, 0, 0), 1)
        '''
        for box in boxes:
            for bp in self.boxes_pre:
                # adaptive threshold by the y coord
                pos_range = int((box[1] / org_h) * 8) + 1
                size_range = int((box[1] / org_h) * 6) + 1
                if (abs(box[0] - bp[0]) < pos_range) & (abs(box[1] - bp[1]) < pos_range) and ((abs(box[2] - bp[2]) < size_range) & (abs(box[3] - bp[3]) < size_range)):
                    bp[4] = bp[4] + 1
                    box[4] = bp[4]

        self.boxes_pre = boxes
        if self.objoccurtimes == self.objoccurtimes_maxnum:
            self.bgfg_outputboxes = [box for box in self.boxes_pre if box[4]>self.objoccurtimes_judgenum]
            self.objoccurtimes = 0
        else:
            self.objoccurtimes += 1

        return self.bgfg_outputboxes

    def if_insert(self, t, location,cam_id):
        #print('if insert')
        #print('db_search_start\t', str(self.db_search_startt))
        #print('judget\t', str(t-3*60))
        if self.db_search_startt > t-3*60:
            return False
        
        centerx = (location[0] + location[2])/2
        centery = (location[1] + location[3])/2
        startt = self.db_search_startt
        endt = t
        where = {'time':{'$gt':startt, '$lt':endt}, 'cameraid': cam_id}
        obj_infos = list(obj_tb.find(where))
        
        ifinsert = True
        for obj_info in obj_infos:
            org_h = 600
            pos_range = int((location[3] + location[1])/2/org_h * 8) + 1

            loca_his = obj_info['location']
            centerx_his = (loca_his[0] + loca_his[2])/2
            centery_his = (loca_his[1] + loca_his[3])/2
                
            if abs(centerx_his - centerx) < pos_range or abs(centerx_his - centerx) < pos_range:
                ifinsert = False
                break
        
        if ifinsert:
            self.db_search_startt = t
        
        #print('if insert\t', str(ifinsert), '\tself.db_search_startt\t', str(self.db_search_startt))
        return ifinsert

    def judge_car_accident(self, cameraid, nowtime):
        initt = time.time()

        t = nowtime
        where = {'time':{'$gt':t-2, '$lt':t}, 'cameraid':cameraid}
        self.rec_cars = list(car_tb.find(where))

        if not self.rec_cars:
            print(self.camera_id, 'stop cars\n[]')
            return []

        ts = []
        for car in self.rec_cars:
            ts.append(car['time'])
        ts = sorted(ts)
        recentt = ts[-1]

        temp = []
        for car in self.rec_cars:
            if car['time'] == recentt:
                temp.append(car)
        self.rec_cars = temp

        where = {'time':{'$gt':t-22, '$lt':t-2}, 'cameraid':cameraid}
        search_cars = list(car_tb.find(where))
        
        stop_cars = []
        for car in self.rec_cars:
            anc_location = car['location']
            anc_centery = int((anc_location[3] - anc_location[1])/2 + anc_location[1])
            anc_centerx = int((anc_location[2] - anc_location[0])/2 + anc_location[0])
            anchor_w = int(anc_location[2] - anc_location[0])
            anchor_h = int(anc_location[3] - anc_location[1])
            shift_w = int(anchor_w/8)
            shift_h = int(anchor_h/8)
            
            count = 0
            for sear_car in search_cars:
                location = sear_car['location']
                centery = int((location[3] - location[1])/2 + location[1])
                centerx = int((location[2] - location[0])/2 + location[0])
                if abs(centerx-anc_centerx)<shift_w and abs(centery-anc_centery)<shift_h:
                    count += 1
            if count>10:
                stop_cars.append(anc_location)
        print(self.camera_id,'stop cars\n', str(stop_cars), '\t', 'judge cost time\t', str(time.time() - initt))
        
        return stop_cars

    def accident_ifinsert(self, t, location,cam_id):
        centerx = (location[0] + location[2])/2
        centery = (location[1] + location[3])/2
        startt = self.db_search_startt
        endt = t
        where = {'time':{'$gt':startt, '$lt':endt}, 'cameraid': cam_id}
        obj_infos = list(accident_tb.find(where))
        
        ifinsert = True
        for obj_info in obj_infos:
            org_h = 600
            pos_range = int((location[3] - location[1])/10)

            loca_his = obj_info['location']
            centerx_his = (loca_his[0] + loca_his[2])/2
            centery_his = (loca_his[1] + loca_his[3])/2
                
            if abs(centerx_his - centerx) < pos_range and abs(centerx_his - centerx) < pos_range:
                ifinsert = False
                break
        
        return ifinsert
    
    def draw_rect(self, nowtime):
        self.save_image = self.image.copy()
        self.bgfg_outputboxes = self.find_coutours_update_boxes(self.fg_bin)

        org_var = copy.deepcopy(self.image_road)
        org_var_roi = org_var * self.mask
        var_gray = cv2.cvtColor(org_var_roi, cv2.COLOR_BGR2GRAY)

        mask_var = calc_variance(var_gray,size=5, stride=2)
        mask_var = cv2.resize(mask_var,(self.image_road.shape[1],self.image_road.shape[0]))

        rawimagepath = _objrawimgsavepath + self.camera_id + '_' + str(nowtime) + '.jpg'

        #get stop cars in this pic
        img_upload = False
        if nowtime > self.car_accident_time + 20 and self.ifsave_video == False:
            self.car_accident_time = nowtime
            self.stop_cars = self.judge_car_accident(self.camera_id, nowtime)
            for car in self.stop_cars:
                y = int((car[1] + car[3]) /2)
                y = int((1080-y)/1080 * 250 + 20)
                cameraid = self.camera_id
                pos_1, pos_2 = geo_loc[cameraid]
                pos_2 += y
                if pos_2>1000:
                    pos_2 -= 1000
                    pos_1 += 1
                position = 'K' + str(pos_1) + '+' + str(pos_2)
                objid = str(uuid.uuid1())
                info = ''
                point = (int((car[0] + car[2])/2), car[3])
                info = region_judge(point, cameraid.lower())
                saferank = 2
                if info == 'edge':
                    saferank = 2
                elif info == 'road':
                    saferank = 0               

                acciinfo = {'imagepath':rawimagepath, 'cameraid':cameraid, 'time':nowtime, 'location':car, 'position':position, 'saferank':saferank,'objid':objid, 'state':0, 'info':info}
                
                ifinsert = self.accident_ifinsert(nowtime, car, cameraid)
                if ifinsert:
                    img_upload = True
                    self.ifsave_video = True
                    self.save_video_type = 'car'

                    self.videoname = '/media/assests/ObjVideos/' + cameraid + '_' + str(nowtime) + '.avi'
                    self.savevideo = cv2.VideoWriter(self.videoname, fourcc, 20.0, (1366, 768))
                    acciinfo['videopath'] = '/media/assests/Objvideos/' + cameraid + '_' + str(nowtime) + '.avi'
                    accident_tb.insert_one(acciinfo)
                    obj_tb.insert_one(acciinfo)
        
        if self.ifsave_video == True and nowtime < self.car_accident_time + 60:
            for car in self.stop_cars:
                cv2.rectangle(self.save_image, (car[0], car[1]), (car[2], car[3]), (0, 0, 255), 2)
            
        for box in self.bgfg_outputboxes:
            if self.ifsave_video == True:
                break
            #break
            x0 = max(int(box[0] - box[2] / 2)-10,0)
            y0 = max(int(box[1] - box[3] / 2)-10,0)
            x1 = min(int(box[0] + box[2] / 2)+10,self.fg_bin.shape[1])
            y1 = min(int(box[1] + box[3] / 2)+10,self.fg_bin.shape[0])
            objimage = self.image_road[y0:y1, x0:x1]
            if ((mask_var[y0:y1, x0:x1]>0.05).sum() / (box[2]*box[3])>0.75) and (HighWayObjDetect.objval.varify_cv(objimage)):
                #print('mask var:', (mask_var[y0:y1, x0:x1]>0.05).sum() / (box[2]*box[3]))
                print(self.camera_id, ' find some thing\t', str(datetime.datetime.now()))
                self.rightcount += 1
                #print('true', str(self.rightcount))
                x0_org = x0 + self.roi_w
                y0_org = y0 + self.roi_h
                x1_org = x1 + self.roi_w
                y1_org = y1 + self.roi_h
                cv2.rectangle(self.save_image, (x0_org, y0_org), (x1_org, y1_org), (0, 0, 255), 2)
                
                location = [x0_org, y0_org, x1_org, y1_org]
                cameraid = self.camera_id
                y = (location[1] + location[3])/2
                y = int((1080-y)/1080 * 250 + 20)
                pos_1, pos_2 = geo_loc[cameraid]
                pos_2 += y
                if pos_2>1000:
                    pos_2 -= 1000
                    pos_1 += 1
                position = 'K' + str(pos_1) + '+' + str(pos_2)

                area = (x1_org-x0_org)*(y1_org-y0_org)
                saferank = 2
                if area > 10000:
                    saferank = 0
                elif area > 2500 and saferank>1:
                    saferank = 1

                objid = str(uuid.uuid1())
                info = ''
                #state: 0-wait for handling, 1-had handled, 2-ignore
                objinfo = {'imagepath':rawimagepath, 'cameraid':cameraid, 'time':nowtime, 'location':location, 'position':position, 'saferank':saferank,'objid':objid, 'state':0, 'info':info}
                print(objinfo) 
                ifinsert = self.if_insert(nowtime, location, cameraid)
                if ifinsert:
                    img_upload = True
                    self.ifsave_video = True
                    self.save_video_type = 'obj'

                    self.videoname = '/media/assests/ObjVideos/' + cameraid + '_' + str(nowtime) + '.avi'
                    self.savevideo = cv2.VideoWriter(self.videoname, fourcc, 20.0, (1366, 768))
                    objinfo['videopath'] = '/media/assests/Objvideos/' + cameraid + '_' + str(nowtime) + '.avi'
                    obj_tb.insert_one(objinfo)
                    print('-------start video--------\n')
            else:
                self.failcount += 1
                self.bgfg_outputboxes.remove(box)
                #cv2.rectangle(self.vis, (x0, y0), (x1, y1), (0, 255, 0), 2)
                #print('false ', str(self.failcount))

        if img_upload:
            lowppi_frame = cv2.resize(self.save_image, (800, 450))
            ret, buffer = cv2.imencode('.jpg', lowppi_frame)
            if ret:
                b64img = base64.b64encode(buffer)
                up_thread = threading.Thread(target=upload, args=(rawimagepath, b64img,))
                #upload(rawimagepath, b64img)
                up_thread.start()
                print('upload image\t', rawimagepath)

        if self.ifsave_video:
            lowppi_frame = cv2.resize(self.save_image, (1366, 768))
            self.savevideo.write(lowppi_frame)
            #print('write frame')
            if nowtime - self.db_search_startt > 3*60-30 and self.save_video_type == 'obj':
                self.ifsave_video = False
                self.savevideo.release()
                videoname = self.videoname.split('/')[-1]
                initt = time.time()
                

                up_thread = threading.Thread(target=upload_video, args=(self.videoname, videoname,))
                up_thread.start()
                #upload_video(self.videoname, videoname)
                print('upload \t', videoname, '\t', str(time.time() - initt))
                print('--------end video---------\n')

            if nowtime - self.car_accident_time > 3*60-30 and self.save_video_type == 'car':
                self.ifsave_video = False
                self.savevideo.release()
                
                videoname = self.videoname.split('/')[-1]
                initt = time.time()
                up_thread = threading.Thread(target=upload_video, args=(self.videoname, videoname,))
                #upload_video(self.videoname, videoname)
                up_thread.start()
                print('upload \t', videoname, '\t', str(time.time() - initt))
                print('--------end video---------\n')
            
        
        self.lastt = nowtime
        
        #cv2.imshow('save_image', self.save_image)

    def step(self, frame, nowtime):
        #print(nowtime)
        self.build_bg(frame)
        self.extract_fg()
        #self.visualization()
        if self.build_bg_done:
            self.draw_rect(nowtime)

    def visualization(self):
        if self.build_bg_done:
            cv2.imshow('fg', self.fg)
            cv2.imshow('bg_pre', self.bg_pre)
            cv2.imshow('fg_bin', self.fg_bin)
            cv2.imshow('road', self.image_road)

            cv2.waitKey(1)


if __name__ == '__main__' :

    test_video = './videofortest/test_TV52_01.mp4'
    cap = cv2.VideoCapture(test_video)
    # process per process_count
    process_count = 20
    count = 0
    detect_obj = HighWayObjDetect('tv52')

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if count % process_count == 0:
            detect_obj.step(frame)

        count += 1
