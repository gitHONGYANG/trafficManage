nohup python ./vis_basereader.py 'TV36'  > ./log/log36_vis.txt 2>&1 &
nohup python ./vis_basereader.py 'TV37'  > ./log/log37_vis.txt 2>&1 &
nohup python ./vis_basereader.py 'TV38'  > ./log/log38_vis.txt 2>&1 &
nohup python ./vis_basereader.py 'TV40'  > ./log/log40_vis.txt 2>&1 &
nohup python ./vis_basereader.py 'TV41'  > ./log/log41_vis.txt 2>&1 &
nohup python ./vis_basereader.py 'TV42'  > ./log/log42_vis.txt 2>&1 &
