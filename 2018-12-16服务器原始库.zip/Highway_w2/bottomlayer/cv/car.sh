nohup python ./cv_basereader.py 'TV46'  > ./log/log57.txt 2>&1 &
