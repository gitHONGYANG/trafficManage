export PATH=/home/highway/anaconda3/bin:$PATH
nohup python /home/highway/HighWay/toplayer/utils/isrtsp_connect.py 1 10 > /home/highway/HighWay/toplayer/log/isconnect1.txt 2>&1 &
nohup python /home/highway/HighWay/toplayer/utils/isrtsp_connect.py 11 20 > /home/highway/HighWay/toplayer/log/isconnect2.txt 2>&1 &
nohup python /home/highway/HighWay/toplayer/utils/isrtsp_connect.py 21 30 > /home/highway/HighWay/toplayer/log/isconnect3.txt 2>&1 &
nohup python /home/highway/HighWay/toplayer/utils/isrtsp_connect.py 31 40 > /home/highway/HighWay/toplayer/log/isconnect4.txt 2>&1 &
nohup python /home/highway/HighWay/toplayer/utils/isrtsp_connect.py 41 50 > /home/highway/HighWay/toplayer/log/isconnect5.txt 2>&1 &
nohup python /home/highway/HighWay/toplayer/utils/isrtsp_connect.py 51 60 > /home/highway/HighWay/toplayer/log/isconnect6.txt 2>&1 &
nohup python /home/highway/HighWay/toplayer/utils/isrtsp_connect.py 61 70 > /home/highway/HighWay/toplayer/log/isconnect7.txt 2>&1 &
nohup python /home/highway/HighWay/toplayer/utils/isrtsp_connect.py 71 80 > /home/highway/HighWay/toplayer/log/isconnect8.txt 2>&1 &
nohup python /home/highway/HighWay/toplayer/utils/isrtsp_connect.py 81 90 > /home/highway/HighWay/toplayer/log/isconnect9.txt 2>&1 &
nohup python /home/highway/HighWay/toplayer/utils/isrtsp_connect.py 91 100 > /home/highway/HighWay/toplayer/log/isconnect10.txt 2>&1 &
